

<script>
   //export default  {
   module.export = {

   }
</script>

<style>
   .example {
      color: red;
   }
</style>