<p>Estimado/a: <br></p>

<p>
   Su llave secreta es: <b>{{$llave}}</b>
</p>

<p>
   Para crear su clave debe usar esta llave entregada, e ingresarla con los datos solicitados en el formulario de solicitud ubicado en este enlace:
</p>

<p>
   <a href="http://tv.minsal.cl/crea_clave">http://tv.minsal.cl/crea_clave</a>
</p>